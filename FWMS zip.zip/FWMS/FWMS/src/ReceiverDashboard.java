import javax.swing.*;
import java.awt.*;
import java.sql.*;

public class ReceiverDashboard extends JFrame {
    private JComboBox<String> categoryComboBox;
    private JComboBox<String> foodComboBox;
    private JTextField quantityField;
    private JTextArea displayArea;
    private int receiverId;

    public ReceiverDashboard(int receiverId) {
        this.receiverId = receiverId;

        setTitle("Receiver Dashboard");
        setSize(1300, 670);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        // Header
        JLabel headerLabel = new JLabel("Food Waste Management - Receiver Dashboard");
        headerLabel.setFont(new Font("Arial", Font.BOLD, 24));
        headerLabel.setForeground(Color.WHITE);
        JPanel headerPanel = new JPanel();
        headerPanel.setBackground(Color.decode("#4CAF50"));
        headerPanel.add(headerLabel);

        categoryComboBox = new JComboBox<>();
        foodComboBox = new JComboBox<>();
        quantityField = new JTextField(5);
        displayArea = new JTextArea();
        displayArea.setEditable(false);

        JPanel formPanel = new JPanel(new GridLayout(7, 1));
        formPanel.add(new JLabel("Category:"));
        formPanel.add(categoryComboBox);
        formPanel.add(new JLabel("Food Item:"));
        formPanel.add(foodComboBox);
        formPanel.add(new JLabel("Quantity:"));
        formPanel.add(quantityField);

        JButton requestButton = new JButton("Request");
        requestButton.addActionListener(e -> requestFood());

        JButton signOutButton = new JButton("Sign Out");
        signOutButton.addActionListener(e -> signOut());

        JPanel buttonPanel = new JPanel();
        buttonPanel.add(requestButton);
        buttonPanel.add(signOutButton);

        JPanel mainPanel = new JPanel(new BorderLayout());
        mainPanel.add(formPanel, BorderLayout.CENTER);
        mainPanel.add(buttonPanel, BorderLayout.SOUTH);

        add(headerPanel, BorderLayout.NORTH);
        add(mainPanel, BorderLayout.CENTER);

        loadCategories();
        categoryComboBox.addActionListener(e -> loadFoods());
    }

    private void loadCategories() {
        try (Connection connection = DatabaseConnection.getConnection()) {
            String query = "SELECT categoryname FROM category";
            Statement statement = connection.createStatement();
            ResultSet resultSet = statement.executeQuery(query);
            while (resultSet.next()) {
                categoryComboBox.addItem(resultSet.getString("categoryname"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void loadFoods() {
        foodComboBox.removeAllItems();
        String category = (String) categoryComboBox.getSelectedItem();

        try (Connection connection = DatabaseConnection.getConnection()) {
            String query = "SELECT itemname, quantity FROM fooditems WHERE categoryid = (SELECT categoryid FROM category WHERE categoryname = ?)";
            PreparedStatement statement = connection.prepareStatement(query);
            statement.setString(1, category);
            ResultSet resultSet = statement.executeQuery();
            while (resultSet.next()) {
                String itemName = resultSet.getString("itemname");
                int quantity = resultSet.getInt("quantity");
                foodComboBox.addItem(itemName + " (Available: " + quantity + ")");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void requestFood() {
        String selectedItem = (String) foodComboBox.getSelectedItem();
        if (selectedItem == null) {
            JOptionPane.showMessageDialog(this, "Please select a food item.");
            return;
        }
        String foodName = selectedItem.split(" \\(")[0];
        int quantity;
        try {
            quantity = Integer.parseInt(quantityField.getText());
            if (quantity < 0) {
                JOptionPane.showMessageDialog(this, "Quantity cannot be negative. Please re-enter.");
                return;
            }
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Invalid quantity format. Please enter a valid number.");
            return;
        }

        try (Connection connection = DatabaseConnection.getConnection()) {
            // Check available quantity
            String checkQuery = "SELECT quantity FROM fooditems WHERE itemname = ?";
            PreparedStatement checkStatement = connection.prepareStatement(checkQuery);
            checkStatement.setString(1, foodName);
            ResultSet resultSet = checkStatement.executeQuery();
            if (resultSet.next()) {
                int availableQuantity = resultSet.getInt("quantity");
                if (quantity > availableQuantity) {
                    JOptionPane.showMessageDialog(this, "Requested quantity exceeds available quantity. Available: " + availableQuantity);
                    return;
                }
            }

            // Insert request
            String query = "INSERT INTO quantityrequest (itemid, quantity, receiverid, date) VALUES ((SELECT itemid FROM fooditems WHERE itemname = ?), ?, ?, CURDATE())";
            PreparedStatement statement = connection.prepareStatement(query);
            statement.setString(1, foodName);
            statement.setInt(2, quantity);
            statement.setInt(3, receiverId);
            statement.executeUpdate();

            // Update food quantity
            String updateQuery = "UPDATE fooditems SET quantity = quantity - ? WHERE itemname = ?";
            PreparedStatement updateStatement = connection.prepareStatement(updateQuery);
            updateStatement.setInt(1, quantity);
            updateStatement.setString(2, foodName);
            updateStatement.executeUpdate();

            JOptionPane.showMessageDialog(this, "Request successful!");
            loadFoods(); // Refresh food items after request
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error during request.");
        }
    }

    private void signOut() {
        new LoginPage().setVisible(true);
        dispose();
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new ReceiverDashboard(1).setVisible(true)); // Placeholder receiverId
    }
}
