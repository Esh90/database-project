import javax.swing.*;
import java.awt.*;
import java.sql.*;

public class LoginPage extends JFrame {
    private JTextField emailField;
    private JPasswordField passwordField;

    public LoginPage() {
        setTitle("Login");
        setSize(800, 500); // Adjusted frame size for better visibility
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        // Header Panel
        JPanel headerPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        headerPanel.setBackground(Color.decode("#4CAF50"));
        JLabel headerLabel = new JLabel("Food Waste Management");
        headerLabel.setFont(new Font("Arial", Font.BOLD, 28));
        headerLabel.setForeground(Color.WHITE);
        headerPanel.add(headerLabel);

        // Login Panel
        JPanel loginPanel = new JPanel(new GridBagLayout());
        loginPanel.setBackground(Color.decode("#f4f4f4"));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);

        JLabel emailLabel = new JLabel("Email:");
        emailField = new JTextField(20);

        JLabel passwordLabel = new JLabel("Password:");
        passwordField = new JPasswordField(20);

        JButton loginButton = new JButton("Login");
        JButton signUpButton = new JButton("Sign Up");

        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.anchor = GridBagConstraints.EAST;
        loginPanel.add(emailLabel, gbc);

        gbc.gridx = 1;
        gbc.anchor = GridBagConstraints.WEST;
        loginPanel.add(emailField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 1;
        gbc.anchor = GridBagConstraints.EAST;
        loginPanel.add(passwordLabel, gbc);

        gbc.gridx = 1;
        gbc.anchor = GridBagConstraints.WEST;
        loginPanel.add(passwordField, gbc);

        JPanel buttonPanel = new JPanel();
        buttonPanel.add(loginButton);
        buttonPanel.add(signUpButton);

        gbc.gridx = 0;
        gbc.gridy = 2;
        gbc.gridwidth = 2;
        gbc.anchor = GridBagConstraints.CENTER;
        loginPanel.add(buttonPanel, gbc);

        // Image Panel
        ImageIcon imageIcon = new ImageIcon("C:\\Users\\ramee\\OneDrive\\Pictures\\fwms3.png"); // Provide the image path
        JLabel imageLabel = new JLabel(imageIcon);
        imageLabel.setPreferredSize(new Dimension(350, 0)); // Set preferred size for the image

        // Footer Panel
        JPanel footerPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        footerPanel.setBackground(Color.decode("#4CAF50"));
        JLabel footerLabel = new JLabel("© 2024 Food Waste Management. All rights reserved.");
        footerLabel.setFont(new Font("Arial", Font.PLAIN, 12));
        footerLabel.setForeground(Color.WHITE);
        footerPanel.add(footerLabel);

        // Split Pane
        JSplitPane splitPane = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, loginPanel, imageLabel);
        splitPane.setDividerLocation(350); // Set initial divider location

        // Main Panel
        JPanel mainPanel = new JPanel(new BorderLayout());
        mainPanel.add(headerPanel, BorderLayout.NORTH);
        mainPanel.add(splitPane, BorderLayout.CENTER);
        mainPanel.add(footerPanel, BorderLayout.SOUTH);

        add(mainPanel);

        // Action listeners
        loginButton.addActionListener(e -> login());
        signUpButton.addActionListener(e -> new SignUpPage().setVisible(true));
    }

    private void login() {
        String email = emailField.getText();
        String password = new String(passwordField.getPassword());

        try (Connection connection = DatabaseConnection.getConnection()) {
            // Construct the SQL query to fetch the role based on email
            String query = "SELECT role FROM (SELECT 'donor' AS role, email FROM donor " +
                    "UNION SELECT 'receiver' AS role, email FROM receiver " +
                    "UNION SELECT 'admin' AS role, email FROM admin) AS roles " +
                    "WHERE email = ? AND EXISTS (SELECT 1 FROM (SELECT email, password FROM donor " +
                    "UNION SELECT email, password FROM receiver " +
                    "UNION SELECT email, password FROM admin) AS users WHERE email = ? AND password = ?)";

            // Prepare and execute the query
            PreparedStatement statement = connection.prepareStatement(query);
            statement.setString(1, email);
            statement.setString(2, email);
            statement.setString(3, password);
            ResultSet resultSet = statement.executeQuery();

            // Process the result
            if (resultSet.next()) {
                String role = resultSet.getString("role");
                int userId = getUserId(connection, email, role); // Fetch user ID based on role
                dispose();

                switch (role) {
                    case "donor":
                        new DonorDashboard().setVisible(true);
                        break;
                    case "receiver":
                        new ReceiverDashboard(userId).setVisible(true);
                        break;
                    case "admin":
                        new AdminDashboard().setVisible(true);
                        break;
                    default:
                        throw new IllegalArgumentException("Unknown role: " + role);
                }
            } else {
                JOptionPane.showMessageDialog(this, "Invalid email or password.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error during login: " + e.getMessage());
        }
    }

    private int getUserId(Connection connection, String email, String role) throws SQLException {
        String query;
        switch (role) {
            case "donor":
                query = "SELECT id FROM donor WHERE email = ?";
                break;
            case "receiver":
                query = "SELECT id FROM receiver WHERE email = ?";

            case "admin":
                query = "SELECT id FROM admin WHERE email = ?";
                break;
            default:
                throw new IllegalArgumentException("Unknown role: " + role);
        }

        PreparedStatement statement = connection.prepareStatement(query);
        statement.setString(1, email);
        ResultSet resultSet = statement.executeQuery();
        if (resultSet.next()) {
            return resultSet.getInt("id");
        } else {
            throw new IllegalStateException("User ID not found for email: " + email);
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new LoginPage().setVisible(true));
    }
}

