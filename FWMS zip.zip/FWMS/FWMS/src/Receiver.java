import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class Receiver {
    private int id;
    private String email;
    private String password;
    private String name;

    public Receiver(int id, String email, String password, String name) {
        this.id = id;
        this.email = email;
        this.password = password;
        this.name = name;
    }

    public static Receiver login(String email, String password) throws SQLException {
        String query = "SELECT * FROM receiver WHERE email = ? AND password = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setString(1, email);
            stmt.setString(2, password);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return new Receiver(rs.getInt("id"), rs.getString("email"), rs.getString("password"), rs.getString("name"));
                }
            }
        }
        return null;
    }
}
