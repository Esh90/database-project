import javax.swing.*;
import java.awt.*;
import java.sql.*;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class DonorDashboard extends JFrame {
    private JComboBox<String> categoryComboBox;
    private JTextField itemNameField;
    private JTextField quantityField;
    private JTextField expiryDateField;

    public DonorDashboard() {
        setTitle("Donor Dashboard");
        setSize(1300, 670);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        // Header
        JLabel headerLabel = new JLabel("Food Waste Management - Donor Dashboard");
        headerLabel.setFont(new Font("Arial", Font.BOLD, 24));
        headerLabel.setForeground(Color.WHITE);
        JPanel headerPanel = new JPanel();
        headerPanel.setBackground(Color.decode("#4CAF50"));
        headerPanel.add(headerLabel);

        categoryComboBox = new JComboBox<>();
        itemNameField = new JTextField(20);
        quantityField = new JTextField(5);
        expiryDateField = new JTextField(10);

        JPanel formPanel = new JPanel(new GridLayout(7, 1));
        formPanel.add(new JLabel("Category:"));
        formPanel.add(categoryComboBox);
        formPanel.add(new JLabel("Item Name:"));
        formPanel.add(itemNameField);
        formPanel.add(new JLabel("Quantity:"));
        formPanel.add(quantityField);
        formPanel.add(new JLabel("Expiry Date (YYYY-MM-DD):"));
        formPanel.add(expiryDateField);

        JButton donateButton = new JButton("Donate");
        donateButton.addActionListener(e -> donate());

        JButton signOutButton = new JButton("Sign Out");
        signOutButton.addActionListener(e -> signOut());

        JPanel buttonPanel = new JPanel();
        buttonPanel.add(donateButton);
        buttonPanel.add(signOutButton);

        JPanel mainPanel = new JPanel(new BorderLayout());
        mainPanel.add(formPanel, BorderLayout.CENTER);
        mainPanel.add(buttonPanel, BorderLayout.SOUTH);

        add(headerPanel, BorderLayout.NORTH);
        add(mainPanel, BorderLayout.CENTER);

        loadCategories();
    }

    private void loadCategories() {
        try (Connection connection = DatabaseConnection.getConnection()) {
            String query = "SELECT categoryname FROM category";
            Statement statement = connection.createStatement();
            ResultSet resultSet = statement.executeQuery(query);
            while (resultSet.next()) {
                categoryComboBox.addItem(resultSet.getString("categoryname"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void donate() {
        String category = (String) categoryComboBox.getSelectedItem();
        String itemName = itemNameField.getText();
        int quantity;
        try {
            quantity = Integer.parseInt(quantityField.getText());
            if (quantity < 0) {
                JOptionPane.showMessageDialog(this, "Quantity cannot be negative. Please re-enter.");
                return;
            }
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Invalid quantity format. Please enter a valid number.");
            return;
        }

        String expiryDateString = expiryDateField.getText();
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        dateFormat.setLenient(false);

        Date expiryDate;
        try {
            expiryDate = dateFormat.parse(expiryDateString);
            Date currentDate = new Date();
            if (expiryDate.before(currentDate)) {
                JOptionPane.showMessageDialog(this, "Expiry date cannot be in the past. Please re-enter.");
                return;
            }
        } catch (ParseException e) {
            JOptionPane.showMessageDialog(this, "Invalid expiry date format. Please enter date in YYYY-MM-DD format.");
            return;
        }

        try (Connection connection = DatabaseConnection.getConnection()) {
            String query = "INSERT INTO fooditems (itemname, categoryid, quantity, expirydate) VALUES (?, (SELECT categoryid FROM category WHERE categoryname = ?), ?, ?)";
            PreparedStatement statement = connection.prepareStatement(query);
            statement.setString(1, itemName);
            statement.setString(2, category);
            statement.setInt(3, quantity);
            statement.setDate(4, new java.sql.Date(expiryDate.getTime()));
            statement.executeUpdate();

            JOptionPane.showMessageDialog(this, "Donation successful!");
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error during donation.");
        }
    }

    private void signOut() {
        new LoginPage().setVisible(true);
        dispose();
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new DonorDashboard().setVisible(true));
    }
}
