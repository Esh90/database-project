import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.*;

public class AdminDashboard extends JFrame {
    private JTable table;
    private DefaultTableModel model;

    public AdminDashboard() {
        setTitle("Admin Dashboard");
        setSize(1300, 670);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        // Header
        JLabel headerLabel = new JLabel("Food Waste Management - Admin Dashboard");
        headerLabel.setFont(new Font("Arial", Font.BOLD, 24));
        headerLabel.setForeground(Color.WHITE);
        JPanel headerPanel = new JPanel();
        headerPanel.setBackground(Color.decode("#4CAF50"));
        headerPanel.add(headerLabel);

        table = new JTable();
        table.setFillsViewportHeight(true);

        // Initialize the table model with no column names initially
        model = new DefaultTableModel();
        table.setModel(model);

        JButton viewDonationsButton = new JButton("View Donations");
        JButton viewRequestsButton = new JButton("View Requests");
        JButton viewInventoryButton = new JButton("View Inventory");
        JButton signOutButton = new JButton("Sign Out");

        JPanel buttonPanel = new JPanel();
        buttonPanel.add(viewDonationsButton);
        buttonPanel.add(viewRequestsButton);
        buttonPanel.add(viewInventoryButton);
        buttonPanel.add(signOutButton);

        // Add components to the frame
        add(headerPanel, BorderLayout.NORTH);
        add(new JScrollPane(table), BorderLayout.CENTER);
        add(buttonPanel, BorderLayout.SOUTH);

        viewDonationsButton.addActionListener(e -> viewDonations());
        viewRequestsButton.addActionListener(e -> viewRequests());
        viewInventoryButton.addActionListener(e -> viewInventory());
        signOutButton.addActionListener(e -> signOut());
    }

    private void viewDonations() {
        model.setColumnIdentifiers(new String[]{"Donor Name", "Food Item", "Quantity", "Date"});
        model.setRowCount(0); // Clear previous data
        try (Connection connection = DatabaseConnection.getConnection()) {
            String query = "SELECT donor.name, fooditems.itemname, donations.quantity, donations.date " +
                    "FROM donations " +
                    "JOIN donor ON donations.donorid = donor.id " +
                    "JOIN fooditems ON donations.itemid = fooditems.itemid";
            Statement statement = connection.createStatement();
            ResultSet resultSet = statement.executeQuery(query);
            while (resultSet.next()) {
                String donorName = resultSet.getString("name");
                String itemName = resultSet.getString("itemname");
                int quantity = resultSet.getInt("quantity");
                Date date = resultSet.getDate("date");
                model.addRow(new Object[]{donorName, itemName, quantity, date});
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void viewRequests() {
        model.setColumnIdentifiers(new String[]{"Receiver Name", "Food Item", "Quantity", "Date"});
        model.setRowCount(0); // Clear previous data
        try (Connection connection = DatabaseConnection.getConnection()) {
            String query = "SELECT receiver.name, fooditems.itemname, quantityrequest.quantity, quantityrequest.date " +
                    "FROM quantityrequest " +
                    "JOIN receiver ON quantityrequest.receiverid = receiver.id " +
                    "JOIN fooditems ON quantityrequest.itemid = fooditems.itemid";
            Statement statement = connection.createStatement();
            ResultSet resultSet = statement.executeQuery(query);
            while (resultSet.next()) {
                String receiverName = resultSet.getString("name");
                String itemName = resultSet.getString("itemname");
                int quantity = resultSet.getInt("quantity");
                Date date = resultSet.getDate("date");
                model.addRow(new Object[]{receiverName, itemName, quantity, date});
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void viewInventory() {
        model.setColumnIdentifiers(new String[]{"Food Item", "Category", "Quantity", "Expiry Date"});
        model.setRowCount(0); // Clear previous data
        try (Connection connection = DatabaseConnection.getConnection()) {
            String query = "SELECT fooditems.itemname, category.categoryname, fooditems.quantity, fooditems.expirydate " +
                    "FROM fooditems " +
                    "JOIN category ON fooditems.categoryid = category.categoryid";
            Statement statement = connection.createStatement();
            ResultSet resultSet = statement.executeQuery(query);
            while (resultSet.next()) {
                String itemName = resultSet.getString("itemname");
                String categoryName = resultSet.getString("categoryname");
                int quantity = resultSet.getInt("quantity");
                Date expiryDate = resultSet.getDate("expirydate");
                model.addRow(new Object[]{itemName, categoryName, quantity, expiryDate});
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void signOut() {
        new LoginPage().setVisible(true);
        dispose();
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            AdminDashboard dashboard = new AdminDashboard();
            dashboard.setVisible(true);
        });
    }
}
