-- MySQL dump 10.13  Distrib 8.0.36, for Win64 (x86_64)
--
-- Host: localhost    Database: fwms
-- ------------------------------------------------------
-- Server version	8.0.37

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `admin`
--

DROP TABLE IF EXISTS `admin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `admin` (
  `id` int NOT NULL AUTO_INCREMENT,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`),
  UNIQUE KEY `id_UNIQUE` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `admin`
--

LOCK TABLES `admin` WRITE;
/*!40000 ALTER TABLE `admin` DISABLE KEYS */;
INSERT INTO `admin` VALUES (1,'rameen@example.com','password1','Rameen'),(2,'esha@example.com','password2','Esha'),(3,'asawer@example.com','password3','Asawer');
/*!40000 ALTER TABLE `admin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `category`
--

DROP TABLE IF EXISTS `category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `category` (
  `categoryid` int NOT NULL AUTO_INCREMENT,
  `categoryname` varchar(255) NOT NULL,
  PRIMARY KEY (`categoryid`),
  UNIQUE KEY `categoryname` (`categoryname`),
  UNIQUE KEY `categoryid_UNIQUE` (`categoryid`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `category`
--

LOCK TABLES `category` WRITE;
/*!40000 ALTER TABLE `category` DISABLE KEYS */;
INSERT INTO `category` VALUES (1,'Beverages'),(3,'Carbs'),(7,'Dairy'),(5,'Fruits'),(8,'Meat'),(2,'Rice'),(4,'Sweets'),(6,'Vegetables');
/*!40000 ALTER TABLE `category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `donations`
--

DROP TABLE IF EXISTS `donations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `donations` (
  `id` int NOT NULL AUTO_INCREMENT,
  `donorid` int NOT NULL,
  `donorname` varchar(45) NOT NULL,
  `itemid` int NOT NULL,
  `quantity` int unsigned NOT NULL,
  `date` date NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id_UNIQUE` (`id`),
  KEY `donorid` (`donorid`),
  KEY `donations_ibfk_2` (`itemid`),
  CONSTRAINT `donations_ibfk_1` FOREIGN KEY (`donorid`) REFERENCES `donor` (`id`),
  CONSTRAINT `donations_ibfk_2` FOREIGN KEY (`itemid`) REFERENCES `fooditems` (`itemid`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `donations`
--

LOCK TABLES `donations` WRITE;
/*!40000 ALTER TABLE `donations` DISABLE KEYS */;
INSERT INTO `donations` VALUES (1,4,'Asma',6,25,'2024-05-26'),(2,5,'Abid',8,15,'2024-05-21'),(3,6,'Zoya',10,40,'2024-05-22');
/*!40000 ALTER TABLE `donations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `donor`
--

DROP TABLE IF EXISTS `donor`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `donor` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`),
  UNIQUE KEY `id_UNIQUE` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `donor`
--

LOCK TABLES `donor` WRITE;
/*!40000 ALTER TABLE `donor` DISABLE KEYS */;
INSERT INTO `donor` VALUES (1,'Mohammad','mohammad@gmail.com','donorpassword1'),(2,'Fatima','fatima@hotmail.com','donorpassword2'),(3,'Ali','ali@yahoo.com','donorpassword3'),(4,'Asma','asma@gmail.com','donorpassword4'),(5,'Abid','abid@hotmail.com','donorpassword5'),(6,'Zoya','zoya@yahoo.com','donorpassword6'),(7,'as','as@g.com','111'),(9,'Esh','esh@g.com','esh'),(11,'R','r@g.com','rr');
/*!40000 ALTER TABLE `donor` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fooditems`
--

DROP TABLE IF EXISTS `fooditems`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `fooditems` (
  `itemid` int NOT NULL AUTO_INCREMENT,
  `itemname` varchar(45) NOT NULL,
  `categoryid` int NOT NULL,
  `quantity` int unsigned NOT NULL,
  `expirydate` date NOT NULL,
  PRIMARY KEY (`itemid`),
  UNIQUE KEY `itemid_UNIQUE` (`itemid`),
  KEY `categoryid` (`categoryid`),
  CONSTRAINT `fooditems_ibfk_1` FOREIGN KEY (`categoryid`) REFERENCES `category` (`categoryid`)
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fooditems`
--

LOCK TABLES `fooditems` WRITE;
/*!40000 ALTER TABLE `fooditems` DISABLE KEYS */;
INSERT INTO `fooditems` VALUES (1,'Apple Juice',1,100,'2024-06-30'),(2,'Orange Juice',1,50,'2024-07-15'),(3,'Basmati Rice',2,200,'2024-12-31'),(4,'Bread',3,150,'2024-09-30'),(5,'Mango',5,80,'2024-08-15'),(6,'Chicken',8,120,'2024-06-30'),(7,'Carrot',6,70,'2024-07-15'),(8,'Milk',7,300,'2024-12-31'),(9,'Beef',8,200,'2024-09-30'),(10,'Coca Cola',1,90,'2024-08-15'),(11,'Banana',5,55,'2024-05-18'),(12,'Strawberry',5,55,'2024-05-18'),(13,'Grapes',5,55,'2024-05-18'),(14,'Peach',5,55,'2024-05-18'),(15,'Orange',5,55,'2024-05-18'),(16,'Chocolate Cake',4,10,'2024-05-18'),(17,'Candy',4,10,'2024-05-18'),(18,'Ice Cream',4,10,'2024-05-18'),(19,'Donut',4,10,'2024-05-18'),(20,'Cookies',4,10,'2024-05-18'),(21,'Pudding',4,10,'2024-05-18'),(22,'Brownie',4,10,'2024-05-18'),(23,'Yoghurt',7,20,'2024-06-12'),(24,'Coke',1,12,'2024-11-09'),(25,'Coke',1,12,'2024-11-09'),(26,'Coke',1,12,'2024-11-09'),(27,'Coke',1,12,'2024-08-07'),(28,'Beef',8,3,'2024-08-07');
/*!40000 ALTER TABLE `fooditems` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `login`
--

DROP TABLE IF EXISTS `login`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `login` (
  `loginid` int NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  PRIMARY KEY (`loginid`),
  UNIQUE KEY `email` (`email`),
  UNIQUE KEY `loginid_UNIQUE` (`loginid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `login`
--

LOCK TABLES `login` WRITE;
/*!40000 ALTER TABLE `login` DISABLE KEYS */;
/*!40000 ALTER TABLE `login` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `quantityrequest`
--

DROP TABLE IF EXISTS `quantityrequest`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `quantityrequest` (
  `id` int NOT NULL AUTO_INCREMENT,
  `itemid` int NOT NULL,
  `recievername` varchar(45) NOT NULL,
  `date` date NOT NULL,
  `quantity` int unsigned NOT NULL,
  `receiverid` int NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id_UNIQUE` (`id`),
  KEY `itemid` (`itemid`),
  KEY `receiverid` (`receiverid`),
  CONSTRAINT `quantityrequest_ibfk_2` FOREIGN KEY (`receiverid`) REFERENCES `receiver` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `quantityrequest`
--

LOCK TABLES `quantityrequest` WRITE;
/*!40000 ALTER TABLE `quantityrequest` DISABLE KEYS */;
INSERT INTO `quantityrequest` VALUES (1,5,'Kamran','2024-05-25',30,4),(2,6,'Sana','2024-05-20',40,5),(3,7,'Arif','2024-05-21',25,6),(4,11,'Ayesha','2024-05-23',2,1);
/*!40000 ALTER TABLE `quantityrequest` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `receiver`
--

DROP TABLE IF EXISTS `receiver`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `receiver` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`),
  UNIQUE KEY `id_UNIQUE` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `receiver`
--

LOCK TABLES `receiver` WRITE;
/*!40000 ALTER TABLE `receiver` DISABLE KEYS */;
INSERT INTO `receiver` VALUES (1,'Ayesha','ayesha@example.com','receiverpassword1'),(2,'Zainab','zainab@example.com','receiverpassword2'),(3,'Usman','usman@example.com','receiverpassword3'),(4,'Kamran','kamran@example.com','receiverpassword4'),(5,'Sana','sana@example.com','receiverpassword5'),(6,'Arif','arif@example.com','receiverpassword6'),(7,'rrr','r@g.com','rrr'),(8,'rec','rec@r.com','rrr'),(9,'Noor','noor@g.com','noor');
/*!40000 ALTER TABLE `receiver` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-05-19 14:51:03
